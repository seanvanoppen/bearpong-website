# Tiny site for app-ads.txt

This repo exists purely to host `https://YOURDOMAIN/app-ads.txt` for ad verification.
Steps:
1) Replace the placeholder publisher ID in `app-ads.txt`.
2) Push to the `main` branch.
3) Enable Pages in Settings → Pages (Deploy from branch, main, /root).
4) Set your Custom domain to YOURDOMAIN (or www.YOURDOMAIN).
5) Point DNS at this Pages site (A records for apex, CNAME for www).
